﻿using ClickToCareer_WebAPI.Model;
using ClickToCareer_WebAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ClickToCareer_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class StudentController : Controller
    {
        public readonly StudentRepository _studentRepository;
        public StudentController()
        {
            _studentRepository = new StudentRepository();
        }

        [HttpPost]
        public IActionResult Save(StudentData data)
        {

            string result = _studentRepository.Save(data);

            return Ok(result);

        }

    }
}
