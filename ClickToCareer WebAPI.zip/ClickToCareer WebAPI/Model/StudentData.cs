﻿namespace ClickToCareer_WebAPI.Model
{
    public class StudentData
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
