﻿using ClickToCareer_WebAPI.Helper;
using System.Data;
using System.Data.SqlClient;

namespace ClickToCareer_WebAPI.Repository
{
    public class BaseRepository
    {

        public SqlConnection Connection()
        {
            string connectionString = new Connection().GetConnectionString();
            SqlConnection connection = new SqlConnection(connectionString);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            return connection;
        }

    }
}
