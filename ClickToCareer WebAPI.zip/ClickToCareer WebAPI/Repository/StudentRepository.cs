﻿using ClickToCareer_WebAPI.Model;
using System;
using System.Data;
using System.Data.SqlClient;

namespace ClickToCareer_WebAPI.Repository
{
    public class StudentRepository : BaseRepository
    {

        // save to db
        public string Save(StudentData data)
        {
            string response = string.Empty;

            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "USP_STUDENT_SAVE";
                using (SqlConnection connection = Connection())
                {
                    cmd.Connection = connection;
                    cmd.CommandTimeout = 30;
                    cmd.Parameters.Add("@FNAME", SqlDbType.VarChar).Value = data.FirstName;
                    cmd.Parameters.Add("@LNAME", SqlDbType.VarChar).Value = data.LastName;
                    using (SqlDataReader rdr = cmd.ExecuteReader())
                    {
                        if (rdr.HasRows && rdr.Read())
                        {
                            response = rdr.GetString(0);
                        }
                    }
                }
            }
            return response;

        }
    }
}
